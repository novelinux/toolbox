#!/bin/bash
#
# This is a script to parse the load.cmm automatically and use the crash tool
# Used by Qualcomm internal
# Any questions, please contact <jiacangl@qti.qualcomm.com>
#

basepath=$(cd `dirname $0`; pwd)

export CRASH_HOME=$basepath
export CRASH_EXTENSIONS=$CRASH_HOME/plugin
SYMBOL="$1"
FILENAME="$2"
# Usage function
usage()
{
    echo -e "Usage: $0 vmlinux load.cmm \n"
    echo -e "       $0 vmlinux load.cmm <--minimal> <--no_data_debug><...>\n"
    exit
}

para="$CRASH_HOME/crash64 "
blank=" "
comma=","
s=" "

if [ $# -lt 2 ]; then
usage
fi

if [[ "$2" != "load.cmm" ]]; then
usage
fi

while [ "$#" -ge "2" ];do
    t=$3
    s=${s}${t}${blank}
    shift
done

para=${para}${SYMBOL}${blank}
a=0
for i in `cat $FILENAME`
do
    if [ $a -eq 1 ]
        then
            para=${para}${i},
            a=0
    fi

    str1=${i:0:4}
    if test "$str1" = "DDRC"
        then
            para=${para}${i}@
            a=1
    fi
done
b=${#para}
para=${para:0:(b-1)}
para=${para}${s}
echo $para
eval $para
